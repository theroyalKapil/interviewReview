package com.acme.mytrader.common;

public class CommonConstants {

    public static String user = "DBUSER";

    public static String IBM = "IBM";

    public static String TCS = "TCS";

}
